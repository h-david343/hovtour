<?php 
session_start();
@$sess=$_SESSION['log'];


if ($sess===true) {
    


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body>



    <div class="container text-center">

    <button class="btn btn-dark" data-toggle="collapse" data-target="#demo">add carousel</button>

    <div id="demo" class="collapse  col-lg-5 mx-auto">
        <form action="action.php" method="post">
            <input type="text" class="form-control mt-3 mb-3" name="inp1">
            <input type="text" class="form-control mt-3 mb-3 ins-val" name="inp2">
            <input type="file" class="inp-file form-control mt-3 mb-3" data-trip='carousel'>
            <div class="brd ins-car col-lg-5 mx-auto"></div>
            <button class="btn btn-success">ok</button>
        </form>
</div>
        
        <h1>carousel</h1>
    <table border='1' class="carousel table">
        <tr>
            <td>img</td>
            <td>text</td>
            <td>action</td>
</tr>
        <?php
    include "dbconn.php";
    $sql="SELECT * FROM `carousel`";
    $res=mysqli_query($conn,$sql);
    while ($print=mysqli_fetch_assoc($res)){//karevor bana
$carousel=<<<kku
<tr>
    <td><img src='assets/images/carousel/$print[img]' width='250'></td>
    <td><h3>$print[text]</h3></td>
    <td>
<button class="btn btn-danger btn-delete" data-table='carousel' id='$print[id]'>delete</button>
<br>
            <button class="btn btn-success mt-5" data-toggle="collapse" data-target="#demo-carousel-$print[id]">insert</button>

 <div id="demo-carousel-$print[id]" class="collapse  col-lg-12 mx-auto">
        <form action="action.php" method="post">
            <input type="text" class="form-control mt-3 mb-3 text" name="text" value='$print[text]' placeholder="text">
            <input type="hidden" class="form-control mt-3 mb-3 ins-val" name="car_img"  value='$print[img]'>
            <input type="hidden" value='$print[id]' name="id">
            <input type="file" class="inp-file form-control mt-3 mb-3" data-trip='carousel'>
            <div class="brd ins-car col-lg-5 mx-auto"></div>
            <button class="btn btn-success carousel-edit-but">ok</button>
        </form>
</div>
    </td>
</tr>                

kku;
echo $carousel;

}
?>
    </table>

    </div>


    <div class="container text-center">
        <button class="btn btn-dark" data-toggle="collapse" data-target="#demo1">add portfolio</button>

    <div id="demo1" class="collapse  col-lg-5 mx-auto">
        <form action="action.php" method="post">
            <input type="text" class="form-control mt-3 mb-3" name="portfolio-text1">
            <input type="text" class="form-control mt-3 mb-3" name="portfolio-text2">
            <input type="text" class="form-control mt-3 mb-3 ins-val" name="portfolio-img-name">
            <input type="file" class="inp-file form-control mt-3 mb-3" data-trip='portfolio'>
            <input type="checkbox" value="yes" name="portfolio-top">
            <div class="brd ins-car col-lg-5 mx-auto"></div>
            <button class="btn btn-success">ok</button>
        </form>
</div>
        <h1>portfolio</h1>
    <table border=1 class="portfolio table">
    <div class="container"></div>
        <tr>
            <td>img</td>
            <td>text1</td>
            <td>text2</td>

</tr>
        <?php
    include "dbconn.php";
    $sql="SELECT * FROM `portfolio`";
    $res=mysqli_query($conn,$sql);
    while ($print=mysqli_fetch_assoc($res)){//karevor bana
$portfolio=<<<kku
<tr>
    <td><img src='assets/images/portfolio/$print[img]' width='250'></td>
    <td><h3>$print[text1]</h3></td>
    <td><h3>$print[text2]</h3></td>
<td>
<button class="btn btn-danger btn-delete" data-table="portfolio" id='$print[id]'>delete</button>
<br>
            <button class="btn btn-success mt-5 but-port-insert" data-toggle="collapse" data-target="#demo-portfolio-$print[id]">insert</button>

            <div id="demo-portfolio-$print[id]" class="collapse  col-lg-12 mx-auto">
        <form action="action.php" method="post">
            <input type="text" class="form-control mt-3 mb-3 portfolio-text1" name="text1" value='$print[text1]' placeholder="text1">
            <input type="text" class="form-control mt-3 mb-3 portfolio-text2" name="text2" value='$print[text2]' placeholder="text2">
            <input type="hidden" class="form-control mt-3 mb-3 ins-val" name="port_img" value='$print[img]'>
            <input type="hidden" value='$print[id]' name="id">
            <input type="file" class="inp-file form-control mt-3 mb-3" data-trip='portfolio'>
            <input type="checkbox" name="portfolio-top" value='yes' class='port-check $print[top]'>
            <div class="brd ins-car col-lg-5 mx-auto"></div>
            <button class="btn btn-success portfolio-edit-but">ok</button>
        </form>
</div>
    </td>
</tr> 
              
kku;
echo $portfolio;

}
?>
    </table >
    </div>

<div class="container text-center">
    <button class="btn btn-dark" data-toggle="collapse" data-target="#demo-news">Collapsible</button>

    <div id="demo-news" class="collapse  col-lg-5 mx-auto">
        <form action="action.php" method="post">
            <input type="text" class="form-control mt-3 mb-3" name="news-title" placeholder="title">
            <input type="date" class="form-control mt-3 mb-3" name="date">
            <input type="text" class="form-control mt-3 mb-3" name="text" placeholder="text">
            <input type="text" class="form-control mt-3 mb-3 ins-val" name="inp4">
            <input type="file" class="inp-file form-control mt-3 mb-3" data-trip='news'>
            <div class="brd ins-car-news col-lg-5 mx-auto"></div>
            <button class="news-but btn-success btn">ok</button>
        </form>
</div>
        <h1>news</h1>
    

    <table border=1 class="portfolio table">
        <tr>
            <td>img</td>
            <td>title</td>
            <td>date</td>
            <td>text</td>
</tr>
        <?php
    include "dbconn.php";
    $sql="SELECT * FROM `news`";
    $res=mysqli_query($conn,$sql);
    while ($print=mysqli_fetch_assoc($res)){//karevor bana
$news=<<<kku
<tr>
    <td><img src='assets/images/news/$print[img]' width=250'></td>
    <td><h3>$print[title]</h3></td>
    <td><h3>$print[date]</h3></td>
    <td><h3>$print[text]</h3></td>

<td>
    <button class="btn btn-danger btn-delete" data-table="news" id='$print[id]'>delete</button>
    <br>
        <button class="btn btn-success mt-5" data-toggle="collapse" data-target="#demo-news-$print[id]">insert</button>

        <div id="demo-news-$print[id]" class="collapse  col-lg-12 mx-auto">
            <form action="action.php" method="post">
                <input type="text" value='$print[title]' class="form-control mt-3 mb-3 inp-news-title" placeholder="title" name='title'>
                <input type="date" value='$print[date]' class="form-comtrol mt-3mb-3 inp-news-date" name="date">
                <input type="text" value='$print[text]' class="form-control mt-3 mb-3 inp-news-text" placeholder="text" name='text'>
                <input type="hidden" value='$print[id]' name="id">
                <input type="hidden" value='$print[img]' class="form-control mt-3 mb-3 ins-val" name="news_img" >
                <input type="file" class="inp-file form-control mt-3 mb-3"data-trip='news'>
                <div class="brd ins-car col-lg-12 mx-auto"></div>
                <button class="btn btn-success news-edit-but">ok</button>
            </form>
        </div>
    </td>
</tr>                

kku;
echo $news;

}
?>

    </table>
</div>

<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
    <script src="admin.js" defer></script>
</body>
</html>


<?php 

}else{  
    header('location:admin/index.html');
}


?>
