<?php
session_start();
	$login=mysqli_real_escape_string($conn,$_POST['login']);
	$pswd=mysqli_real_escape_string($conn,$_POST['password']);

	include "../dbconn.php";
    $sql="SELECT * FROM `admin` WHERE `login`='$login' AND `password`='$pswd'";
    $res=mysqli_query($conn,$sql);
    $tox=mysqli_num_rows($res);
    if($tox>0){
    	$_SESSION['log']=true;
    	echo('<script>window.location.href="../index-admin.php"</script>');
    }
    else{
    	echo('<h4>no</h4>');
    }
?>