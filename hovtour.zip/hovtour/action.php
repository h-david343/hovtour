<?php 
include 'dbconn.php';

if (isset($_POST['inp1'])&&isset($_POST['inp2'])) {
	
	$a=$_POST['inp1'];
	$b=$_POST['inp2'];


    $sql="INSERT INTO `carousel` (`img`,`text`) VALUES ('$b','$a')";
    $res=mysqli_query($conn,$sql);
    header('location:index-admin.php');



}

if (isset($_POST['id'])&&isset($_POST['text'])&&isset($_POST['car_img'])) {
	$id=$_POST['id'];
    $text=$_POST['text'];
    $car_img=$_POST['car_img'];

    $sql="UPDATE `carousel` SET `text`='$text',`img`='$car_img' WHERE `id`='$id'";
    $res=mysqli_query($conn,$sql);
    header('location:index-admin.php');
}

if (isset($_POST['portfolio-text1'])&&isset($_POST['portfolio-text2'])&&isset($_POST['portfolio-img-name'])) {


$text1=$_POST['portfolio-text1'];
	$text2=$_POST['portfolio-text2'];
    $img=$_POST['portfolio-img-name'];

    $top='';

    if(empty($_POST['portfolio-top'])){
        $top='no';
    }
    else{
        $top=$_POST['portfolio-top'];
	}

    $sql="INSERT INTO `portfolio` (`img`,`text1`,`text2`,`top`) VALUES ('$img','text1','$text2','$top')";
    $res=mysqli_query($conn,$sql);
    header('location:index-admin.php');

}

if(isset($_POST['text1'])&&isset($_POST['text2'])&&isset($_POST['port_img'])&&isset($_POST['id'])){
	$text1=$_POST['text1'];
    $text2=$_POST['text2'];
    $port_img=$_POST['port_img'];
    $id=$_POST['id'];
    $top='';

    if(empty($_POST['portfolio-top'])){
        $top='no';
    }
    else{
        $top=$_POST['portfolio-top'];
    }

    $sql="UPDATE `portfolio` SET `text1`='$text1', `text2`='$text2', `img`='$port_img', `top`='$top' WHERE `id`='$id'";
    $res=mysqli_query($conn,$sql);
    header('location:index-admin.php');
}

if(isset($_POST['news-title'])&&isset($_POST['date'])&&isset($_POST['text'])&&isset($_POST['inp4'])){
		$title=$_POST['news-title'];
	$date=$_POST['date'];
    $text=$_POST['text'];
    $img=$_POST['inp4'];





    $sql="INSERT INTO `news` (`img`,`title`,`date`,`text`) VALUES ('$img','$title','$date','$text')";
    $res=mysqli_query($conn,$sql);
    header('location:index-admin.php');


}
if(isset($_POST['title'])&&isset($_POST['date'])&&isset($_POST['text'])&&isset($_POST['news_img'])&&isset($_POST['id'])){
	$title=$_POST['title'];
    $date=$_POST['date'];
    $text=$_POST['text'];
    $news_img=$_POST['news_img'];
    $id=$_POST['id'];

    $sql="UPDATE `news` SET `title`='$title', `date`='$date', `text`='$text', `img`='$news_img' WHERE `id`='$id'";
    $res=mysqli_query($conn,$sql);
    header('location:index-admin.php');
}
if(isset($_POST['car_id'])&&isset($_POST['data_table'])&&isset($_POST['img'])){
	$car_id=$_POST['car_id'];
    $data_table=$_POST['data_table'];
    $img=$_POST['img'];



    $sql="DELETE FROM `$data_table` WHERE `id`='$car_id'";
    $res=mysqli_query($conn,$sql);
    if ($res) {
        unlink($img);
	}
}

if (isset($_FILES['file'])) {
	    $anun=$_FILES['file']['name'];

    $jamatex=$_FILES['file']['tmp_name'];

    $data_trip=$_POST['trip'];

    $verj=explode('.',$anun);
    if(end($verj)=='jpg' || end($verj)=='png' || end($verj)=='svg'){
        $name=time().'.'.end($verj);
        $chanaparh='assets/images/'.$data_trip.'/'.$name;

        move_uploaded_file($jamatex, $chanaparh);

        echo $name; 
    }



}
if(isset($_POST['b'])){
 $b=$_POST['b'];



    $sql="SELECT * FROM `news` LIMIT $b,3";
    $res=mysqli_query($conn,$sql);
    while ($print=mysqli_fetch_assoc($res)){//karevor bana
$txt=<<<kku
<div class="container news-container">
<div class="col-lg-3 news-img">
<img src="assets/images/news/$print[img]"width="100%">
</div>
<div class="col-lg-7 news-text text-left">
    <h2 class="text-title">$print[title]</h2>
    <i class="news-date">$print[date]</i>
    <p>$print[text]</p>
</div>
</div>
kku;
echo $txt;

}
}
if(isset($_POST['search_val'])){
	$search_val=$_POST['search_val'];

    $sql="SELECT * FROM `portfolio` WHERE `text1` LIKE '%$search_val%'";
    $res=mysqli_query($conn,$sql);
    while ($print=mysqli_fetch_assoc($res)){//karevor bana
$txt=<<<kku
                
<div class="col-sm-4">
									<div class="item">
										<img src="assets/images/portfolio/$print[img]" alt="portfolio image"/>
										<div class="isotope-overlay">
											<div class='column'>
												<a href="#">
													$print[text1]
												</a>
												
												<h4 class='color-widthe'>$print[text2]</h4>
											</div>
										</div>
									</div>
								</div>
kku;
echo $txt;

}

}


?>