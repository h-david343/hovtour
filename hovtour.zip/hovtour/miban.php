   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
<div class="container-fluid text-center p-5">
	
   <h1>Orders</h1>
   <hr>
</div>
<?php
	$id = $_POST['id'];
	include 'dbconn.php';

	$sql="SELECT * FROM `portfolio` WHERE `id`='$id'";
    $res=mysqli_query($conn,$sql);
    $tox=mysqli_num_rows($res);

    	while ($print=mysqli_fetch_assoc($res)){
$txt=<<<kku

<div class="container">
	<div class='row'>
<div class="col-lg-4">
		<img src="assets/images/portfolio/$print[img]"width="250">
	</div>
	<div class="col-lg-4 text-center"><p>$print[text1]</p></div>
	<div class="col-lg-4 text-center"><p>$print[text2]</p></div>
	</div>
	
</div>


kku;

 echo $txt;



}
    


?>	
