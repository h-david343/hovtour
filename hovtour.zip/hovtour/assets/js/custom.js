/*$(document).ready(function(){
	"use strict";*/
    
        /*==================================
* Author        : "ThemeSine"
* Template Name : Khanas HTML Template
* Version       : 1.0
==================================== */



/*=========== TABLE OF CONTENTS ===========
1. Scroll To Top 
2. Smooth Scroll spy
3. Progress-bar
4. owl carousel
5. welcome animation support
======================================*/

    // 1. Scroll To Top 
	/*	$(window).on('scroll',function () {
			if ($(this).scrollTop() > 600) {
				$('.return-to-top').fadeIn();
			} else {
				$('.return-to-top').fadeOut();
			}
		});
		$('.return-to-top').on('click',function(){
				$('html, body').animate({
				scrollTop: 0
			}, 1500);
			return false;
		});
	
	
	
	// 2. Smooth Scroll spy
		
		$('.header-area').sticky({
           topSpacing:0
        });
		
		//=============

		$('li.smooth-menu a').bind("click", function(event) {
			event.preventDefault();
			var anchor = $(this);
			$('html, body').stop().animate({
				scrollTop: $(anchor.attr('href')).offset().top - 0
			}, 1200,'easeInOutExpo');
		});
		
		$('body').scrollspy({
			target:'.navbar-collapse',
			offset:0
		});

	// 3. Progress-bar
	
		var dataToggleTooTip = $('[data-toggle="tooltip"]');
		var progressBar = $(".progress-bar");
		if (progressBar.length) {
			progressBar.appear(function () {
				dataToggleTooTip.tooltip({
					trigger: 'manual'
				}).tooltip('show');
				progressBar.each(function () {
					var each_bar_width = $(this).attr('aria-valuenow');
					$(this).width(each_bar_width + '%');
				});
			});
		}
	
	// 4. owl carousel
	
		// i. client (carousel)
		
			$('#client').owlCarousel({
				items:7,
				loop:true,
				smartSpeed: 1000,
				autoplay:true,
				dots:false,
				autoplayHoverPause:true,
				responsive:{
						0:{
							items:2
						},
						415:{
							items:2
						},
						600:{
							items:4

						},
						1199:{
							items:4
						},
						1200:{
							items:7
						}
					}
				});
				
				
				$('.play').on('click',function(){
					owl.trigger('play.owl.autoplay',[1000])
				})
				$('.stop').on('click',function(){
					owl.trigger('stop.owl.autoplay')
				})
*/

    // 5. welcome animation support

/*        $(window).load(function(){
        	$(".header-text h2,.header-text p").removeClass("animated fadeInUp").css({'opacity':'0'});
            $(".header-text a").removeClass("animated fadeInDown").css({'opacity':'0'});
        });

        $(window).load(function(){
        	$(".header-text h2,.header-text p").addClass("animated fadeInUp").css({'opacity':'0'});
            $(".header-text a").addClass("animated fadeInDown").css({'opacity':'0'});
        });*/

/*});	*/
	
/*==============================================================*/
// Hero slider
/*==============================================================*/
var bannerSlider = $(".banner-slider");
var bannerFirstSlide = $("div.banner-slide:first-child");

bannerSlider.on("init", function (e, slick) {
	var firstAnimatingElements = bannerFirstSlide.find("[data-animation]");
	slideanimate(firstAnimatingElements);
});
bannerSlider.on("beforeChange", function (e, slick, currentSlide, nextSlide) {
	var $animatingElements = $(
		'div.slick-slide[data-slick-index="' + nextSlide + '"]'
	).find("[data-animation]");
	slideanimate($animatingElements);
});
bannerSlider.slick({
	slidesToShow: 1,
	slidesToScroll: 1,
	arrows: true,
	fade: true,
	dots: false,
	swipe: true,
	adaptiveHeight: true,
	responsive: [
		{
			breakpoint: 767,
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				autoplay: false,
				autoplaySpeed: 4000,
				swipe: true
			}
		}
	]
});
function slideanimate(elements) {
	var animationEndEvents =
		"webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend";
	elements.each(function () {
		var inq = $(this);
		var animationDelay = inq.data("delay");
		var animationType = "animated " + inq.data("animation");
		inq.css({
			"animation-delay": animationDelay,
			"-webkit-animation-delay": animationDelay
		});
		inq.addClass(animationType).one(animationEndEvents, function () {
			inq.removeClass(animationType);
		});
	});
}



// data color
$("[data-color]").each(function () {
	$(this).css("color", $(this).attr("data-color"));
});
// data background color
$("[data-bgcolor]").each(function () {
	$(this).css("background-color", $(this).attr("data-bgcolor"));
});





const inp1 = document.querySelector('.inp1')
const prt_cont = document.querySelector('.prt_cont')
inp1.addEventListener('keyup',(e)=>{
	let s_inp=e.target.value
// console.log(e)


	let data =new FormData()
	data.append('search_val',s_inp)

	fetch('action.php',{
		method:'POST',
		body:data
	}).then((response)=>{
		return response.text()
	}).then((res)=>{
		prt_cont.innerHTML=res
	})



})
/*$('.inp1').keyup(function(){
	let s_inp=$(this).val()
	

	$.post('action.php',{
		search_val:s_inp,
	},function(res){
		$('.prt_cont').html(res)
	})
})*/


var qq = 0;


$('.owl-carousel').owlCarousel({
  loop: true,
  margin: 10,
  nav: false,

  autoplay: true,
  autoplayHoverPause: true,
  responsive: {
    0: {
      items: 2
    },
    600: {
      items: 3
    },
    1000: {
      items: 5
    }
  }
})
//---------------
const btns=document.querySelectorAll('.news-but')
btns[0].classList.add('active_page')

$('.news-but').click(function(){
	let a=$(this).html()*3-3


	$('.news-but').removeClass('active_page')
	$(this).addClass('active_page')
	$.post('action.php',{
    b:a
   },function(res){
   	// alert(res)
   	$('.pr').html(res)
   })

})
var xc
var cx
const more = document.querySelectorAll('.more')
more.forEach((elem)=>{

	elem.addEventListener('click', (e)=>{
qq++
		let cc=e.srcElement.offsetParent.offsetParent.offsetParent
		let par=cc.querySelector('.modal-dialog')
		xc=cc
		cx=par
		cc.querySelector('.n1').classList.add('anim1')
		par.classList.add('anim2')
		cc.querySelector('.n1').classList.remove('anim3')
		par.classList.remove('anim4')
		return cc;
		return par;
})
})


const trash = document.querySelectorAll('.trash')
trash.forEach((elem)=>{
	elem.addEventListener('click', ()=>{
		// let cc=e.srcElement.offsetParent.offsetParent.offsetParent
		// let par=cc.querySelector('.modal-dialog')

		xc.querySelector('.n1').classList.remove('anim1')
		cx.classList.remove('anim2')
		xc.querySelector('.n1').classList.add('anim3')
		cx.classList.add('anim4')


		// document.querySelector('.n1').classList.remove('anim1')
		// document.querySelector('.modal-dialog').classList.remove('anim2')
		// document.querySelector('.n1').classList.add('anim3')
		// document.querySelector('.modal-dialog').classList.add('anim4')
})
})
const iostope = document.querySelectorAll('.isotope-overlay')
iostope.forEach((elem)=>{
	elem.addEventListener('click', ()=>{
		if(qq>0){
			let n1 = document.querySelectorAll('.n1')
			let dialog = document.querySelectorAll('.modal-dialog')
			let l = n1.length
			for(let i=0;i<l;i++){
				n1[i].classList.remove('anim1')
				n1[i].classList.remove('anim3')
				dialog[i].classList.remove('anim2')
				dialog[i].classList.remove('anim4')



			}

		}
		// document.querySelector('.n1').classList.remove('anim1')
		// document.querySelector('.modal-dialog').classList.remove('anim2')
		// document.querySelector('.n1').classList.remove('anim3')
		// document.querySelector('.modal-dialog').classList.remove('anim4')
})

})

// $('.isotope-overlay').click(function(){
// 	$('.n1').removeClass('anim1')
// 	$('.modal-dialog').removeClass('anim2')
// 	$('.n1').removeClass('anim3')
// 	$('.modal-dialog').removeClass('anim4')
	
// })


// $('.more').click(function(){
// 	$('.modal-dialog').removeClass('anim4')
// 	$('.n1').removeClass('anim3')
// 	$('.modal-dialog').addClass('anim2')
// 	$('.n1').addClass('anim1')
// })	


// $('.trash').click(function(){
// 	$('.modal-dialog').removeClass('anim2')
// 	$('.modal-dialog').addClass('anim4')
// 	$('.n1').removeClass('anim1')
// 	$('.n1').addClass('anim3')
// })
//-----------

const inputs = document.querySelectorAll('input');

const patterns = {
    name: /^[a-zA-Z\d]{1,12}$/,
    subject: /^[a-z\d-]{1,30}$/,
    message: /^[a-z\d-]{8,20}$/,
    email: /^([a-z\d\.-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,8})?$/
};

//validation function
function validate(field, regex) {
    if(regex.test(field.value)){
        field.className = 'valid';
    }else{
        field.className = 'invalid';
    }
} 

inputs.forEach(input => {
    input.addEventListener('keyup', e => {
        validate(e.target, patterns[e.target.name]);
    });
});
const contact_btn = document.querySelector('.single-contact-btn')
contact_btn.addEventListener('click', ()=>{

	let name = document.querySelector('#name').value
	let email = document.querySelector('#email').value
	let subject = document.querySelector('#subject').value
	let message = document.querySelector('#comment').value
	let data=new FormData();

  	data.append('name', name);
    data.append('email',email);
    data.append('subject',subject);
    data.append('message',message);
 
    // alert(name) 

    fetch('contact.php',{
        method:'POST',
        body:data
    }).then((response)=>{
		return response.text()
	}).then((res)=>{
		document.querySelector('.sss').innerHTML+=res
	})

})