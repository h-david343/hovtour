const inp_file=document.querySelectorAll('.inp-file')
inp_file.forEach((elem)=> {
elem.addEventListener('change',(e)=>{
    let data=new FormData();
    let b = e.target.getAttribute('data-trip');
    let target = e.target.parentElement;
    data.append('file',e.target.files[0]);
    data.append('trip',b);


    fetch('action.php',{
        method:'POST',
        body:data
    }).then((response)=>{
        return response.text()
    }).then((res)=>{
        target.querySelector('.brd').innerHTML=`<img src="assets/images/${b}/${res}" width='100%'>`
        target.querySelector('.ins-val').value=res
    })

})  
});

// $('.inp-file').change(function(){
//     let r=new FormData();
//     let b=$(this).attr('data-trip');
//     let parent=$(this).parent()

//     r.append('file',$(this)[0].files[0]);
//     r.append('trip',b);
//     $.ajax({
//         url:'action.php',
//         data:r,
//         processData:false,
//         contentType:false,
//         type:'POST',
//         success:function(res){
//         parent.find('.brd').html(`<img src="assets/images/${b}/${res}" width='100%'>`)
//         parent.find('.ins-val').val(res)

//         }
//     })

 
// })


const delBtn=document.querySelectorAll('.btn-delete')

delBtn.forEach((elem)=> {
    elem.addEventListener('click',(e)=>{
        // console.log(e)
        let a=e.target.id
        let b=e.target.getAttribute('data-table')
        let parent= e.target.parentElement.parentElement
        let img=parent.querySelector('img').getAttribute('src')

        let data = new FormData()
        data.append('car_id',a)
        data.append('data_table',b)
        data.append('img',img)

    
        fetch('action.php',{
            method:'POST',
            body:data
        })
        // console.log(parent)
        parent.style.display = 'none'
    })
});



// $('.btn-delete').click(function(){
//     let a=this.id;
//     let b=$(this).attr('data-table')
//     let img=$(this).parents('tr').find('img').attr('src')
    
//  $.post('action.php',{
//     car_id:a,
//     data_table:b,
//     img:img
//    })
//     $(this).parents('tr').hide(500)

// })


const check = document.querySelectorAll('.yes')

check.forEach((e)=>{
e.checked=true
})
// $('.yes').prop('checked',true)
