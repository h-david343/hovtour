<?php
    $username='root';
    $password='';
    $servername='localhost';
    $dbname='hovhannes';
    $conn=mysqli_connect($servername,$username,$password,$dbname);
    if($conn){
        // echo 'kpav';
    }
    else{
        echo 'chkpav';
    }
?>